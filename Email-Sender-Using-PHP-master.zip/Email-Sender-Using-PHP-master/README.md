For using this application you need to install sendmail plugin of PHP and configure in Apache server to your email id.
Unzip the sendmail.zip file install & use it.

DON'T TEST THIS WITH ANONYMOUS EMAIL ID. TEST WITH YOUR OWN ID.
